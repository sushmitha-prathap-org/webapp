import User from "./user.js";
import Assignment from "./assignment.js";

export default { User, Assignment };
